const axios = require('axios');

async function testAnthropicAPI() {
    // Hardcode your API key here
    const API_KEY = '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';

    const url = 'https://api.anthropic.com/v1/messages';

    const headers = {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
    };

    const data = {
        model: 'claude-3.7-sonnet',
        max_tokens: 100,
        messages: [
            {
                role: 'user',
                content: 'hi'
            }
        ]
    };

    try {
        console.log('Making API call to Anthropic...');

        const response = await axios.post(url, data, { headers });

        console.log('✅ Success!');
        console.log('Response:', JSON.stringify(response.data, null, 2));

        if (response.data.content && response.data.content[0]) {
            console.log('\n🤖 Claude says:', response.data.content[0].text);
        }

    } catch (error) {
        console.error('❌ Error:', error.response?.data || error.message);

        if (error.response?.status === 401) {
            console.error('🔑 Check your API key!');
        }
    }
}

// Run the test
testAnthropicAPI(); 